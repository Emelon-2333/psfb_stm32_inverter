/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "arm_math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
int16_t sine[720]={0,16,33,49,66,82,99,115,132,149,165,182,198,215,231,247,264,
280,297,313,329,346,362,378,395,411,427,443,459,475,491,507,523,
539,555,571,587,602,618,634,649,665,680,696,711,727,742,757,772,
787,802,817,832,847,862,877,891,906,921,935,949,964,978,992,1006,
1020,1034,1048,1062,1076,1089,1103,1116,1130,1143,1156,1169,1182,1195,1208,1221,
1233,1246,1258,1271,1283,1295,1307,1319,1331,1343,1355,1366,1378,1389,1400,1411,
1423,1433,1444,1455,1466,1476,1486,1497,1507,1517,1527,1537,1546,1556,1565,1575,
1584,1593,1602,1611,1620,1628,1637,1645,1653,1661,1669,1677,1685,1692,1700,1707,
1714,1721,1728,1735,1742,1748,1755,1761,1767,1773,1779,1785,1791,1796,1801,1807,
1812,1816,1821,1826,1830,1835,1839,1843,1847,1851,1854,1858,1861,1865,1868,1871,
1873,1876,1879,1881,1883,1885,1887,1889,1891,1892,1894,1895,1896,1897,1898,1898,
1899,1899,1899,1899,1899,1899,1899,1898,1898,1897,1896,1895,1894,1892,1891,1889,
1887,1885,1883,1881,1879,1876,1873,1871,1868,1865,1861,1858,1854,1851,1847,1843,
1839,1835,1830,1826,1821,1816,1812,1807,1801,1796,1791,1785,1779,1773,1767,1761,
1755,1748,1742,1735,1728,1721,1714,1707,1700,1692,1685,1677,1669,1661,1653,1645,
1637,1628,1620,1611,1602,1593,1584,1575,1565,1556,1546,1537,1527,1517,1507,1497,
1486,1476,1466,1455,1444,1433,1423,1411,1400,1389,1378,1366,1355,1343,1331,1319,
1307,1295,1283,1271,1258,1246,1233,1221,1208,1195,1182,1169,1156,1143,1130,1116,
1103,1089,1076,1062,1048,1034,1020,1006,992,978,964,950,935,921,906,891,
877,862,847,832,817,802,787,772,757,742,727,711,696,680,665,649,
634,618,602,587,571,555,539,523,507,491,475,459,443,427,411,395,
378,362,346,329,313,297,280,264,247,231,215,198,182,165,149,132,
115,99,82,66,49,33,16,0,-17,-34,-50,-67,-83,-100,-116,-133,
-150,-166,-183,-199,-216,-232,-248,-265,-281,-298,-314,-330,-347,-363,-379,-396,
-412,-428,-444,-460,-476,-492,-508,-524,-540,-556,-572,-588,-603,-619,-635,-650,
-666,-681,-697,-712,-728,-743,-758,-773,-788,-803,-818,-833,-848,-863,-878,-892,
-907,-922,-936,-950,-965,-979,-993,-1007,-1021,-1035,-1049,-1063,-1077,-1090,-1104,-1117,
-1131,-1144,-1157,-1170,-1183,-1196,-1209,-1222,-1234,-1247,-1259,-1272,-1284,-1296,-1308,-1320,
-1332,-1344,-1356,-1367,-1379,-1390,-1401,-1412,-1424,-1434,-1445,-1456,-1467,-1477,-1487,-1498,
-1508,-1518,-1528,-1538,-1547,-1557,-1566,-1576,-1585,-1594,-1603,-1612,-1621,-1629,-1638,-1646,
-1654,-1662,-1670,-1678,-1686,-1693,-1701,-1708,-1715,-1722,-1729,-1736,-1743,-1749,-1756,-1762,
-1768,-1774,-1780,-1786,-1792,-1797,-1802,-1808,-1813,-1817,-1822,-1827,-1831,-1836,-1840,-1844,
-1848,-1852,-1855,-1859,-1862,-1866,-1869,-1872,-1874,-1877,-1880,-1882,-1884,-1886,-1888,-1890,
-1892,-1893,-1895,-1896,-1897,-1898,-1899,-1899,-1900,-1900,-1900,-1900,-1900,-1900,-1900,-1899,
-1899,-1898,-1897,-1896,-1895,-1893,-1892,-1890,-1888,-1886,-1884,-1882,-1880,-1877,-1874,-1872,
-1869,-1866,-1862,-1859,-1855,-1852,-1848,-1844,-1840,-1836,-1831,-1827,-1822,-1817,-1813,-1808,
-1802,-1797,-1792,-1786,-1780,-1774,-1768,-1762,-1756,-1749,-1743,-1736,-1729,-1722,-1715,-1708,
-1701,-1693,-1686,-1678,-1670,-1662,-1654,-1646,-1638,-1629,-1621,-1612,-1603,-1594,-1585,-1576,
-1566,-1557,-1547,-1538,-1528,-1518,-1508,-1498,-1487,-1477,-1467,-1456,-1445,-1434,-1424,-1412,
-1401,-1390,-1379,-1367,-1356,-1344,-1332,-1320,-1308,-1296,-1284,-1272,-1259,-1247,-1234,-1222,
-1209,-1196,-1183,-1170,-1157,-1144,-1131,-1117,-1104,-1090,-1077,-1063,-1049,-1035,-1021,-1007,
-993,-979,-965,-951,-936,-922,-907,-892,-878,-863,-848,-833,-818,-803,-788,-773,
-758,-743,-728,-712,-697,-681,-666,-650,-635,-619,-603,-588,-572,-556,-540,-524,
-508,-492,-476,-460,-444,-428,-412,-396,-379,-363,-347,-330,-314,-298,-281,-265,
-248,-232,-216,-199,-183,-166,-150,-133,-116,-100,-83,-67,-50,-34,-17};

uint16_t Counter = 0;
uint16_t Sine_Counter = 0;
uint16_t Phase_CCR = 1;
uint16_t Power_Duty = 0;//0��1000��PI������������
uint16_t ARR = 18;
uint16_t Sine_ARR = 720;
uint16_t Uadc = 0;

uint8_t Upsfb_OK = 0;//ǰ����־λ
float32_t softstart = 0;//��������
typedef struct{
  uint16_t Brust_Threshold;
  uint16_t Brust_Flag;     //0��ʾ�رգ�1��ʾ���� 
	uint16_t Brust_Duty;
	float32_t Bk;
}Brust,*M_Brust;
typedef struct{
  float32_t Uref;
	float32_t Kp;
	float32_t Ki;
	float32_t Uerr;
	float32_t Integral;
	float32_t integral_Max;
	float32_t Uout_Max;
	float32_t Uout;
}Upi,*M_Upi;
Brust Br={0,0,0,0};
Upi   Upsfb={0,0,0,0,0,0,0,0};
void Inverter_Init(M_Brust br,M_Upi uo){
  br->Brust_Threshold = 54;
  br->Bk = (float32_t)ARR/br->Brust_Threshold;
	
	uo->Kp = 0.002;
	uo->Ki = 0.0000003;
	uo->Uref = 3500;
	uo->Uout_Max = 1000;
	uo->integral_Max = 200;
}
void Upsfb_Pi(M_Upi uo,uint16_t Uin){
	
  uo->Uerr = (float32_t)uo->Uref - Uin;
	
	uo->Integral += uo->Uerr*uo->Ki;
	
	if(uo->Integral > uo->integral_Max) uo->Integral = uo->integral_Max;
	if(uo->Integral < -uo->integral_Max) uo->Integral = -uo->integral_Max;
	
	uo->Uout += uo->Uerr*uo->Kp + uo->Integral;
	
	if(uo->Uout > uo->Uout_Max) uo->Uout = uo->Uout_Max;
	if(uo->Uout < 0) uo->Uout = 0;
}//ǰ��PI
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
    if (htim == (&htim2)){
			Counter++;
			Sine_Counter++;
			if(Sine_Counter >= Sine_ARR) Sine_Counter = 0;
//**************************************************
//			if(sine[Sine_Counter]>0){
//				  TIM2->CCR1 = (uint16_t)sine[Sine_Counter]*softstart;
//					TIM2->CCR2 = 0;
//					TIM2->CCR3 = 0;
//					if(Sine_Counter >   0 && Sine_Counter < 360)TIM2->CCR4 = 2000;
//				  else TIM2->CCR4 = 0;
//				}else{
//				  TIM2->CCR1 = 0;
//					if(Sine_Counter > 361 && Sine_Counter < 719)TIM2->CCR2 = 2000;
//					else TIM2->CCR2 = 0;
//					TIM2->CCR3 = (uint16_t)-sine[Sine_Counter]*softstart;
//					TIM2->CCR4 = 0;				
//				}//�������¹��Զ��͵�ƽ������оƬ��fd2103
//***************************************************
			if(sine[Sine_Counter]>0){
				  TIM2->CCR1 = (uint16_t)sine[Sine_Counter]*softstart;
					TIM2->CCR2 = (uint16_t)sine[Sine_Counter]*softstart + 10;
					TIM2->CCR3 = 0;
					if(Sine_Counter >   0 && Sine_Counter < 360)TIM2->CCR4 = 0;
				  else TIM2->CCR4 = 2000;
				}else{
				  TIM2->CCR1 = 0;
					if(Sine_Counter > 361 && Sine_Counter < 719)TIM2->CCR2 = 0;
					else TIM2->CCR2 = 2000;
					TIM2->CCR3 = (uint16_t)-sine[Sine_Counter]*softstart;
					TIM2->CCR4 = (uint16_t)-sine[Sine_Counter]*softstart + 10;				
				}//������nsi6602���������������������
//***************************************************				
			if(Counter == Br.Brust_Duty){
				if(Br.Brust_Flag != 0){
			    TIM1->CCR1 = 0;
				  TIM3->CCR2 = 0;
				}//Brust Mode Reset
			}
			if(Counter >= ARR){
				HAL_ADC_Start(&hadc1);
			  Counter=0;
				//Brust Mode Set
				if(Power_Duty <= Br.Brust_Threshold){
				  Phase_CCR     =  Br.Brust_Threshold;
          Br.Brust_Duty =  (uint16_t)Power_Duty*Br.Bk;							
					Br.Brust_Flag =  1;
				}else{
			    Br.Brust_Flag =  0;
	        Phase_CCR  =  Power_Duty;
				}
       if(Br.Brust_Duty != 0 || Br.Brust_Flag == 0){				
				TIM1->CCR1 = 1000;
				TIM3->CCR2 = 1000;
			 }
			  Uadc = HAL_ADC_GetValue(&hadc1);
			  Upsfb_Pi((M_Upi)&Upsfb,Uadc);
        Power_Duty = (uint16_t)Upsfb.Uout;
			 
				TIM1->CCR2 = Phase_CCR+1;
			}//��·�ж�
    }
}
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
	Inverter_Init((M_Brust)&Br,(M_Upi)&Upsfb);
  HAL_TIM_Base_Start(&htim1);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_Base_Start(&htim3);
	
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);	
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);	
	
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_4);//������Ƶż����Ƶ��12һ�ԣ�34һ��
	HAL_Delay(1500);
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    if(Uadc > 2500) Upsfb_OK = 1;
		if(Upsfb_OK == 1){
			while(softstart <= 1){
				softstart += 0.01;
				HAL_Delay(10);
			}
		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
